import { Component } from '@angular/core';

@Component({
  selector: 'app-elszamolas',
  templateUrl: './elszamolas.component.html',
  styleUrls: ['./elszamolas.component.css']
})
export class ElszamolasComponent {

  valasztottUzemanyag: string = "";
  norma!: number;
  utikoltseg!: number;
  egysegar!: number;
  megtett_ut!: number;
  amortizacio!: number;
  osszkoltseg!: number;
  nincsNyomtatas: boolean = true;

  szamolas(): void {
    if (this.norma && this.egysegar && this.megtett_ut) {
      this.utikoltseg = Math.round(this.norma * this.egysegar * this.megtett_ut / 100);
      this.amortizacio = Math.round(this.megtett_ut * 15);
      this.osszkoltseg = Math.round(this.utikoltseg + this.amortizacio);
      this.nincsNyomtatas = false;
    }
    else {
      alert("Töltsd ki a számításhoz szükséges mezőket!");
    }
  }

  nyomtatas(): void {
    window.print();
  }
}
