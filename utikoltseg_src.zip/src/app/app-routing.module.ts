import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ElszamolasComponent } from './elszamolas/elszamolas.component';

const routes: Routes = [
  {path: "elszamolas", component:ElszamolasComponent},
  {path: "", redirectTo:"elszamolas", pathMatch:'full'},
  {path: "**", component: ElszamolasComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
