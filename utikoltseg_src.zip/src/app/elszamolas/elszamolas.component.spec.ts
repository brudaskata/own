import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ElszamolasComponent } from './elszamolas.component';

describe('ElszamolasComponent', () => {
  let component: ElszamolasComponent;
  let fixture: ComponentFixture<ElszamolasComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ElszamolasComponent]
    });
    fixture = TestBed.createComponent(ElszamolasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
